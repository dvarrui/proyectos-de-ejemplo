#!/usr/bin/ruby

hour=`date +%H%M`

if hour<="1400" then
	system('puppet apply /root/bin/ies-users-01.pp')
else 
	system('puppet apply /root/bin/ies-users-02.pp')
end

